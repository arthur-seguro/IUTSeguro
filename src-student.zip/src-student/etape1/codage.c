#include "../commun/td3.h"


extern Handler HANDLER_TABLE[PALETTE_SIZE];
extern char ALPHABET_PALETTE[PALETTE_SIZE];
extern char* NOM_FICHIERS[PALETTE_SIZE];

//choix de la palette a utiliser
char* palette_courante = ALPHABET_PALETTE;


void codage(int in)
{


}


void decodage(int out)
{


}
